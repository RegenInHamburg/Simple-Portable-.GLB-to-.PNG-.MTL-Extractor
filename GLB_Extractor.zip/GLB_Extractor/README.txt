GLB Extractor
=============

What it does
------------
Select one or more .glb files, pick an output folder, hit CONVERT.
For each GLB you get a subfolder containing:
  - <name>.obj   - real geometry (vertices, normals, UVs, faces), with
                   per-node transforms baked in and materials assigned
                   per face group via "usemtl"
  - <name>.mtl   - one material per glTF material, referencing textures
  - *.png        - every embedded/external texture, extracted and
                   converted to PNG

Limitations of the OBJ conversion
----------------------------------
- Only triangle meshes are converted (glTF draw mode 4, the overwhelming
  majority of GLB files). Point clouds / line primitives are skipped
  and noted as a comment in the .obj file.
- Skinning/animation data is not exported (OBJ has no concept of bones)
  - you get the mesh in its bind pose.
- Vertex colors and multiple UV sets are not exported (only TEXCOORD_0).

Two ways to run it
-------------------

OPTION A - You already have Python on this PC
  Just double-click GLB_Extractor.bat. It will pip-install pygltflib
  and pillow if missing, then launch the GUI. File dialogs always open
  in this folder, not wherever Windows happened to launch Python from.

OPTION B - Fully portable, no Python required on the target PC
  1. On a PC with internet access, double-click build_portable_runtime.bat
     ONCE. It downloads a private copy of Python into a "runtime" folder
     next to this script (a few minutes, ~15 MB).
  2. Zip the whole GLB_Extractor folder (including runtime\).
  3. On ANY Windows PC, unzip and double-click GLB_Extractor.bat.
     It detects runtime\python.exe automatically and needs nothing
     else installed - no PATH changes, no admin rights, no internet.

Why the runtime isn't already in this ZIP
-------------------------------------------
The build step downloads Python and packages from python.org / PyPI,
which requires an internet connection at build time. I can't fetch
those binaries on your behalf ahead of time, so build_portable_runtime.bat
does it for you, once, and after that the folder is fully self-contained.
