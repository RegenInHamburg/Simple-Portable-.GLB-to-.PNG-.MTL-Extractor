@echo off
setlocal
cd /d "%~dp0"

if exist "%~dp0runtime\python.exe" (
    echo Using bundled portable Python runtime...
    "%~dp0runtime\python.exe" "%~dp0glb_extractor_gui.py"
) else (
    echo No bundled runtime found - using system Python instead.
    echo (Run build_portable_runtime.bat once to make this ZIP fully standalone.)
    python -m pip install --quiet pygltflib pillow
    if errorlevel 1 (
        echo.
        echo Could not find/install via system Python. Install Python from
        echo https://www.python.org/downloads/  and check "Add to PATH", or
        echo run build_portable_runtime.bat to bundle a private runtime instead.
        pause
        exit /b 1
    )
    python "%~dp0glb_extractor_gui.py"
)

pause
