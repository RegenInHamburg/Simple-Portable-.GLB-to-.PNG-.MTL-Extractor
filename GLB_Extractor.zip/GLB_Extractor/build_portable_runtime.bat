@echo off
setlocal
cd /d "%~dp0"

echo ============================================================
echo  Building portable runtime for GLB Extractor
echo  (this needs an internet connection - run it ONCE)
echo ============================================================
echo.

set PYVER=3.11.9
set PYZIP=python-%PYVER%-embed-amd64.zip
set PYURL=https://www.python.org/ftp/python/%PYVER%/%PYZIP%
set GETPIPURL=https://bootstrap.pypa.io/get-pip.py

if exist "runtime\python.exe" (
    echo runtime\python.exe already exists - delete the "runtime" folder first
    echo if you want to rebuild it from scratch.
    pause
    exit /b 0
)

echo [1/5] Downloading portable Python %PYVER% ...
powershell -NoProfile -Command "Invoke-WebRequest -Uri '%PYURL%' -OutFile '%TEMP%\%PYZIP%'"
if errorlevel 1 goto :fail

echo [2/5] Extracting to runtime\ ...
powershell -NoProfile -Command "Expand-Archive -Path '%TEMP%\%PYZIP%' -DestinationPath 'runtime' -Force"
if errorlevel 1 goto :fail

echo [3/5] Enabling pip / site-packages in the embedded runtime ...
for %%f in (runtime\python*._pth) do (
    powershell -NoProfile -Command "(Get-Content '%%f') -replace '#import site','import site' | Set-Content '%%f'"
)

echo [4/5] Downloading and running get-pip.py ...
powershell -NoProfile -Command "Invoke-WebRequest -Uri '%GETPIPURL%' -OutFile '%TEMP%\get-pip.py'"
if errorlevel 1 goto :fail
"runtime\python.exe" "%TEMP%\get-pip.py" --no-warn-script-location
if errorlevel 1 goto :fail

echo [5/5] Installing pygltflib and pillow into the portable runtime ...
"runtime\python.exe" -m pip install --no-warn-script-location pygltflib pillow
if errorlevel 1 goto :fail

echo.
echo ============================================================
echo  Done! The "runtime" folder now contains a private, portable
echo  Python. You can ZIP this whole "GLB_Extractor" folder and
echo  it will run on any Windows PC with no installation needed.
echo ============================================================
pause
exit /b 0

:fail
echo.
echo Build failed - check your internet connection and try again.
pause
exit /b 1
