import os
import sys
import struct
import base64
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

try:
    from PIL import Image
    from io import BytesIO
except ImportError:
    Image = None

try:
    from pygltflib import GLTF2
except ImportError:
    GLTF2 = None


# --------------------------------------------------------------------------
# Small matrix / quaternion helpers (no numpy dependency, keeps the tool
# truly portable). Matrices are 4x4, row-major, stored as list-of-lists.
# --------------------------------------------------------------------------

def mat4_identity():
    return [[1.0, 0.0, 0.0, 0.0],
            [0.0, 1.0, 0.0, 0.0],
            [0.0, 0.0, 1.0, 0.0],
            [0.0, 0.0, 0.0, 1.0]]


def mat4_from_gltf_columns(m):
    # glTF stores 4x4 matrices column-major as a flat list of 16 floats.
    return [[m[0], m[4], m[8], m[12]],
            [m[1], m[5], m[9], m[13]],
            [m[2], m[6], m[10], m[14]],
            [m[3], m[7], m[11], m[15]]]


def mat4_mul(a, b):
    r = [[0.0] * 4 for _ in range(4)]
    for i in range(4):
        for j in range(4):
            r[i][j] = sum(a[i][k] * b[k][j] for k in range(4))
    return r


def mat4_translation(t):
    m = mat4_identity()
    m[0][3], m[1][3], m[2][3] = t
    return m


def mat4_rotation_from_quat(r):
    x, y, z, w = r
    xx, yy, zz = x * x, y * y, z * z
    xy, xz, yz = x * y, x * z, y * z
    wx, wy, wz = w * x, w * y, w * z
    return [
        [1 - 2 * (yy + zz), 2 * (xy - wz), 2 * (xz + wy), 0.0],
        [2 * (xy + wz), 1 - 2 * (xx + zz), 2 * (yz - wx), 0.0],
        [2 * (xz - wy), 2 * (yz + wx), 1 - 2 * (xx + yy), 0.0],
        [0.0, 0.0, 0.0, 1.0],
    ]


def mat4_scale(s):
    return [[s[0], 0.0, 0.0, 0.0],
            [0.0, s[1], 0.0, 0.0],
            [0.0, 0.0, s[2], 0.0],
            [0.0, 0.0, 0.0, 1.0]]


def mat4_from_trs(t, r, s):
    return mat4_mul(mat4_translation(t), mat4_mul(mat4_rotation_from_quat(r), mat4_scale(s)))


def mat4_transform_point(m, p):
    x, y, z = p
    v = [x, y, z, 1.0]
    out = [sum(m[i][k] * v[k] for k in range(4)) for i in range(4)]
    if abs(out[3]) > 1e-12 and abs(out[3] - 1.0) > 1e-9:
        return (out[0] / out[3], out[1] / out[3], out[2] / out[3])
    return (out[0], out[1], out[2])


def mat3_from_mat4(m):
    return [[m[0][0], m[0][1], m[0][2]],
            [m[1][0], m[1][1], m[1][2]],
            [m[2][0], m[2][1], m[2][2]]]


def mat3_inverse_transpose(m3):
    a, b, c = m3[0]
    d, e, f = m3[1]
    g, h, i = m3[2]
    det = a * (e * i - f * h) - b * (d * i - f * g) + c * (d * h - e * g)
    if abs(det) < 1e-12:
        return m3
    inv_det = 1.0 / det
    # transpose(inverse(M)) == (1/det) * cofactor_matrix(M)
    cof = [
        [(e * i - f * h), -(d * i - f * g), (d * h - e * g)],
        [-(b * i - c * h), (a * i - c * g), -(a * h - b * g)],
        [(b * f - c * e), -(a * f - c * d), (a * e - b * d)],
    ]
    return [[cof[r][col] * inv_det for col in range(3)] for r in range(3)]


def mat3_mul_vec(m3, v):
    return tuple(sum(m3[i][j] * v[j] for j in range(3)) for i in range(3))


def normalize_vec(v):
    l = (v[0] ** 2 + v[1] ** 2 + v[2] ** 2) ** 0.5
    if l < 1e-12:
        return v
    return (v[0] / l, v[1] / l, v[2] / l)


# --------------------------------------------------------------------------
# glTF accessor decoding
# --------------------------------------------------------------------------

COMPONENT_FORMATS = {
    5120: ('b', 1),  # BYTE
    5121: ('B', 1),  # UNSIGNED_BYTE
    5122: ('h', 2),  # SHORT
    5123: ('H', 2),  # UNSIGNED_SHORT
    5125: ('I', 4),  # UNSIGNED_INT
    5126: ('f', 4),  # FLOAT
}

TYPE_COMPONENT_COUNTS = {
    'SCALAR': 1, 'VEC2': 2, 'VEC3': 3, 'VEC4': 4,
    'MAT2': 4, 'MAT3': 9, 'MAT4': 16,
}


def get_buffer_bytes(gltf, buffer_index, glb_dir, cache):
    if buffer_index in cache:
        return cache[buffer_index]
    buffer = gltf.buffers[buffer_index]
    if not buffer.uri:
        data = gltf.binary_blob()
    elif buffer.uri.startswith('data:'):
        _, encoded = buffer.uri.split(',', 1)
        data = base64.b64decode(encoded)
    else:
        path = os.path.join(glb_dir, buffer.uri.replace('/', os.sep))
        with open(path, 'rb') as f:
            data = f.read()
    cache[buffer_index] = data
    return data


def read_accessor(gltf, accessor_index, glb_dir, buffer_cache):
    accessor = gltf.accessors[accessor_index]
    num_components = TYPE_COMPONENT_COUNTS[accessor.type]
    count = accessor.count

    if accessor.bufferView is None:
        # Sparse-only or empty accessor; return zeros rather than crash.
        return [tuple([0.0] * num_components) for _ in range(count)]

    bv = gltf.bufferViews[accessor.bufferView]
    blob = get_buffer_bytes(gltf, bv.buffer, glb_dir, buffer_cache)

    fmt_char, comp_size = COMPONENT_FORMATS[accessor.componentType]
    tight_stride = comp_size * num_components
    stride = bv.byteStride or tight_stride
    base_offset = (bv.byteOffset or 0) + (accessor.byteOffset or 0)

    values = []
    for i in range(count):
        start = base_offset + i * stride
        raw = struct.unpack_from('<' + fmt_char * num_components, blob, start)
        if accessor.normalized:
            if accessor.componentType == 5121:
                raw = tuple(x / 255.0 for x in raw)
            elif accessor.componentType == 5123:
                raw = tuple(x / 65535.0 for x in raw)
            elif accessor.componentType == 5120:
                raw = tuple(max(x / 127.0, -1.0) for x in raw)
            elif accessor.componentType == 5122:
                raw = tuple(max(x / 32767.0, -1.0) for x in raw)
        values.append(raw)
    return values


def get_node_world_matrices(gltf):
    matrices = {}
    scene_index = gltf.scene if gltf.scene is not None else 0
    if not gltf.scenes:
        return matrices
    scene = gltf.scenes[scene_index]

    def recurse(node_idx, parent_matrix):
        node = gltf.nodes[node_idx]
        if node.matrix:
            local = mat4_from_gltf_columns(node.matrix)
        else:
            t = node.translation if node.translation else [0.0, 0.0, 0.0]
            r = node.rotation if node.rotation else [0.0, 0.0, 0.0, 1.0]
            s = node.scale if node.scale else [1.0, 1.0, 1.0]
            local = mat4_from_trs(t, r, s)
        world = mat4_mul(parent_matrix, local)
        matrices[node_idx] = world
        for child in (node.children or []):
            recurse(child, world)

    for root in (scene.nodes or []):
        recurse(root, mat4_identity())
    return matrices


class GLBExtractor:
    def __init__(self, root):
        self.root = root
        self.root.title("GLB Texture & MTL Extractor")
        self.root.geometry("720x520")
        self.root.minsize(620, 460)
        self.files = []
        self.output_dir = ""

        # Always anchor file dialogs to the folder this script lives in,
        # regardless of the working directory Windows launched Python from.
        self.script_dir = os.path.dirname(os.path.abspath(__file__))
        self.last_input_dir = self.script_dir
        self.last_output_dir = self.script_dir

        self.bg = "#171717"
        self.panel = "#202020"
        self.input_bg = "#2a2a2a"
        self.fg = "#eeeeee"
        self.muted = "#a8a8a8"
        self.accent = "#5b8cff"
        self.accent_hover = "#719bff"

        root.configure(bg=self.bg)
        self.setup_style()
        self.build_ui()

    def setup_style(self):
        style = ttk.Style()
        style.theme_use("clam")
        style.configure("TFrame", background=self.bg)
        style.configure("Panel.TFrame", background=self.panel)
        style.configure("TLabel", background=self.bg, foreground=self.fg, font=("Segoe UI", 10))
        style.configure("Muted.TLabel", background=self.bg, foreground=self.muted, font=("Segoe UI", 9))
        style.configure("Title.TLabel", background=self.bg, foreground=self.fg,
                         font=("Segoe UI Semibold", 18))
        style.configure("TButton", font=("Segoe UI", 10), padding=(12, 8),
                         background=self.input_bg, foreground=self.fg, borderwidth=0)
        style.map("TButton", background=[("active", "#383838")])
        style.configure("Convert.TButton", font=("Segoe UI Semibold", 11), padding=(20, 10),
                         background=self.accent, foreground="white", borderwidth=0)
        style.map("Convert.TButton", background=[("active", self.accent_hover)])

    def build_ui(self):
        main = ttk.Frame(self.root, padding=20)
        main.pack(fill="both", expand=True)

        ttk.Label(main, text="GLB Extractor", style="Title.TLabel").pack(anchor="w")
        ttk.Label(main, text="Convert GLB to OBJ + MTL, and extract embedded textures as PNG.",
                  style="Muted.TLabel").pack(anchor="w", pady=(2, 18))

        ttk.Label(main, text="Input GLB files").pack(anchor="w")
        row = ttk.Frame(main)
        row.pack(fill="x", pady=(5, 8))

        self.file_label = tk.Label(
            row, text="No files selected", anchor="w",
            bg=self.input_bg, fg=self.muted, padx=10, pady=9
        )
        self.file_label.pack(side="left", fill="x", expand=True)
        ttk.Button(row, text="Select GLBs…", command=self.select_files).pack(side="left", padx=(8, 0))

        self.listbox = tk.Listbox(
            main, height=8, bg=self.input_bg, fg=self.fg,
            selectbackground=self.accent, selectforeground="white",
            relief="flat", highlightthickness=0, font=("Consolas", 9)
        )
        self.listbox.pack(fill="both", expand=True, pady=(0, 14))

        ttk.Label(main, text="Output folder").pack(anchor="w")
        outrow = ttk.Frame(main)
        outrow.pack(fill="x", pady=(5, 16))

        self.output_label = tk.Label(
            outrow, text="No output folder selected", anchor="w",
            bg=self.input_bg, fg=self.muted, padx=10, pady=9
        )
        self.output_label.pack(side="left", fill="x", expand=True)
        ttk.Button(outrow, text="Choose…", command=self.select_output).pack(side="left", padx=(8, 0))

        opts = ttk.Frame(main)
        opts.pack(fill="x", pady=(0, 16))

        self.obj_var = tk.BooleanVar(value=True)
        self.textures_var = tk.BooleanVar(value=True)
        self.mtl_var = tk.BooleanVar(value=True)

        tk.Checkbutton(opts, text="OBJ (real geometry)", variable=self.obj_var,
                        bg=self.bg, fg=self.fg, activebackground=self.bg,
                        activeforeground=self.fg, selectcolor=self.input_bg).pack(side="left", padx=(0, 18))
        tk.Checkbutton(opts, text="Textures (PNG)", variable=self.textures_var,
                        bg=self.bg, fg=self.fg, activebackground=self.bg,
                        activeforeground=self.fg, selectcolor=self.input_bg).pack(side="left", padx=(0, 18))
        tk.Checkbutton(opts, text="MTL", variable=self.mtl_var,
                        bg=self.bg, fg=self.fg, activebackground=self.bg,
                        activeforeground=self.fg, selectcolor=self.input_bg).pack(side="left")

        self.status = tk.StringVar(value="Ready")
        ttk.Label(main, textvariable=self.status, style="Muted.TLabel").pack(anchor="w", pady=(0, 8))

        self.convert_btn = ttk.Button(main, text="CONVERT", style="Convert.TButton",
                                       command=self.convert)
        self.convert_btn.pack(fill="x")

    # ---------------------------------------------------------------- UI --

    def select_files(self):
        files = filedialog.askopenfilenames(
            title="Select GLB files",
            initialdir=self.last_input_dir,
            filetypes=[("GLB files", "*.glb"), ("All files", "*.*")]
        )
        if not files:
            return
        self.files = list(files)
        self.last_input_dir = os.path.dirname(self.files[0])
        self.listbox.delete(0, tk.END)
        for f in self.files:
            self.listbox.insert(tk.END, f)
        self.file_label.config(text=f"{len(self.files)} file(s) selected", fg=self.fg)

    def select_output(self):
        folder = filedialog.askdirectory(title="Choose output folder", initialdir=self.last_output_dir)
        if not folder:
            return
        self.output_dir = folder
        self.last_output_dir = folder
        self.output_label.config(text=folder, fg=self.fg)

    # ------------------------------------------------------------ extract --

    def extract_images(self, gltf, base_dir, glb_dir):
        extracted = {}
        for i, img in enumerate(gltf.images or []):
            name = os.path.basename(img.name or f"texture_{i}")
            stem, _ = os.path.splitext(name)
            out_name = stem + ".png"
            try:
                if img.uri:
                    if img.uri.startswith("data:"):
                        encoded = img.uri.split(",", 1)[1]
                        raw = base64.b64decode(encoded)
                        if Image:
                            Image.open(BytesIO(raw)).convert("RGBA").save(os.path.join(base_dir, out_name), "PNG")
                        else:
                            out_name = name
                            with open(os.path.join(base_dir, out_name), "wb") as f:
                                f.write(raw)
                        extracted[i] = out_name
                    else:
                        src = os.path.join(glb_dir, img.uri.replace("/", os.sep))
                        if os.path.exists(src):
                            if Image:
                                Image.open(src).convert("RGBA").save(os.path.join(base_dir, out_name), "PNG")
                            else:
                                import shutil
                                out_name = name
                                shutil.copyfile(src, os.path.join(base_dir, out_name))
                            extracted[i] = out_name
                elif img.bufferView is not None:
                    blob = gltf.binary_blob()
                    bv = gltf.bufferViews[img.bufferView]
                    off = bv.byteOffset or 0
                    raw = blob[off:off + bv.byteLength]
                    if Image:
                        Image.open(BytesIO(raw)).convert("RGBA").save(os.path.join(base_dir, out_name), "PNG")
                        extracted[i] = out_name
                    else:
                        ext = ".jpg" if (img.mimeType or "").lower() in ("image/jpeg", "jpeg") else ".bin"
                        out_name = stem + ext
                        with open(os.path.join(base_dir, out_name), "wb") as f:
                            f.write(raw)
                        extracted[i] = out_name
            except Exception:
                continue
        return extracted

    def build_material_names(self, gltf):
        names = {}
        used = set()
        for i, mat in enumerate(gltf.materials or []):
            base = (mat.name or f"Material_{i}").strip().replace(" ", "_").replace("\n", "_") or f"Material_{i}"
            name = base
            n = 1
            while name in used:
                name = f"{base}_{n}"
                n += 1
            used.add(name)
            names[i] = name
        names[None] = "DefaultMaterial"
        return names

    def write_mtl(self, gltf, out_path, texture_names, material_names):
        lines = []
        materials = list(enumerate(gltf.materials or []))

        for i, mat in materials:
            name = material_names[i]
            lines += [f"newmtl {name}", "Ns 32.000", "Ka 1.000 1.000 1.000",
                      "Kd 1.000 1.000 1.000", "Ks 0.000 0.000 0.000", "d 1.0", "illum 2"]
            tex_index = None
            if mat.pbrMetallicRoughness and mat.pbrMetallicRoughness.baseColorTexture:
                tex_index = mat.pbrMetallicRoughness.baseColorTexture.index
                tex_index = gltf.textures[tex_index].source if tex_index is not None else None
            if tex_index is not None and tex_index in texture_names:
                lines.append(f"map_Kd {texture_names[tex_index]}")
            lines.append("")

        # Always include a default material so OBJ references never dangle.
        lines += ["newmtl DefaultMaterial", "Ns 32.000", "Ka 1.000 1.000 1.000",
                  "Kd 0.800 0.800 0.800", "Ks 0.000 0.000 0.000", "d 1.0", "illum 2", ""]

        with open(out_path, "w", encoding="utf-8") as f:
            f.write("\n".join(lines))

    def write_obj(self, gltf, glb_dir, out_path, mtl_name, material_names):
        node_matrices = get_node_world_matrices(gltf)
        buffer_cache = {}

        verts, norms, uvs = [], [], []
        face_blocks = []  # list of (material_name, [ (v,vt,vn) triples per face ])
        skipped_modes = set()

        # Fallback: if the file has no scene graph, still walk every mesh once.
        node_mesh_pairs = []
        if node_matrices:
            for node_idx, node in enumerate(gltf.nodes or []):
                if node.mesh is not None and node_idx in node_matrices:
                    node_mesh_pairs.append((node.mesh, node_matrices[node_idx]))
        if not node_mesh_pairs:
            for mesh_idx in range(len(gltf.meshes or [])):
                node_mesh_pairs.append((mesh_idx, mat4_identity()))

        for mesh_idx, world in node_mesh_pairs:
            mesh = gltf.meshes[mesh_idx]
            normal_mat = mat3_inverse_transpose(mat3_from_mat4(world))

            for prim in mesh.primitives:
                mode = prim.mode if prim.mode is not None else 4
                if mode != 4:
                    skipped_modes.add(mode)
                    continue

                pos_idx = getattr(prim.attributes, "POSITION", None)
                if pos_idx is None:
                    continue
                positions = read_accessor(gltf, pos_idx, glb_dir, buffer_cache)

                norm_idx = getattr(prim.attributes, "NORMAL", None)
                normals = read_accessor(gltf, norm_idx, glb_dir, buffer_cache) if norm_idx is not None else None

                uv_idx = getattr(prim.attributes, "TEXCOORD_0", None)
                texcoords = read_accessor(gltf, uv_idx, glb_dir, buffer_cache) if uv_idx is not None else None

                base_vertex = len(verts)
                for p in positions:
                    verts.append(mat4_transform_point(world, p))

                base_normal = len(norms)
                if normals:
                    for n in normals:
                        tn = mat3_mul_vec(normal_mat, n)
                        norms.append(normalize_vec(tn))

                base_uv = len(uvs)
                if texcoords:
                    for uv in texcoords:
                        uvs.append((uv[0], 1.0 - uv[1]))  # flip V: glTF top-left -> OBJ bottom-left

                if prim.indices is not None:
                    idx_data = read_accessor(gltf, prim.indices, glb_dir, buffer_cache)
                    indices = [int(v[0]) for v in idx_data]
                else:
                    indices = list(range(len(positions)))

                mat_name = material_names.get(prim.material, material_names[None])
                triangles = []
                for t in range(0, len(indices) - 2, 3):
                    tri = []
                    for k in range(3):
                        vi = indices[t + k] + base_vertex + 1
                        vt = (indices[t + k] + base_uv + 1) if texcoords else None
                        vn = (indices[t + k] + base_normal + 1) if normals else None
                        tri.append((vi, vt, vn))
                    triangles.append(tri)
                face_blocks.append((mat_name, triangles))

        with open(out_path, "w", encoding="utf-8") as f:
            f.write(f"# Converted from GLB: {os.path.basename(out_path)}\n")
            f.write(f"mtllib {mtl_name}\n\n")
            for v in verts:
                f.write(f"v {v[0]:.6f} {v[1]:.6f} {v[2]:.6f}\n")
            for uv in uvs:
                f.write(f"vt {uv[0]:.6f} {uv[1]:.6f}\n")
            for n in norms:
                f.write(f"vn {n[0]:.6f} {n[1]:.6f} {n[2]:.6f}\n")

            current_mat = None
            for mat_name, triangles in face_blocks:
                if mat_name != current_mat:
                    f.write(f"\nusemtl {mat_name}\n")
                    current_mat = mat_name
                for tri in triangles:
                    parts = []
                    for vi, vt, vn in tri:
                        if vt is not None and vn is not None:
                            parts.append(f"{vi}/{vt}/{vn}")
                        elif vt is not None:
                            parts.append(f"{vi}/{vt}")
                        elif vn is not None:
                            parts.append(f"{vi}//{vn}")
                        else:
                            parts.append(f"{vi}")
                    f.write("f " + " ".join(parts) + "\n")

            if skipped_modes:
                f.write(f"\n# Note: primitive draw mode(s) {sorted(skipped_modes)} were skipped "
                        f"(only TRIANGLES/mode 4 is supported).\n")

        if not verts:
            raise RuntimeError("No triangle geometry found in this GLB (only skinned/point/line "
                                "primitives or an empty scene).")

    def convert_one(self, src):
        if GLTF2 is None:
            raise RuntimeError("pygltflib is not installed.")
        name = os.path.splitext(os.path.basename(src))[0]
        out = os.path.join(self.output_dir, name)
        os.makedirs(out, exist_ok=True)
        glb_dir = os.path.dirname(os.path.abspath(src))

        gltf = GLTF2().load(src)

        material_names = self.build_material_names(gltf)

        texture_names = {}
        if self.textures_var.get():
            texture_names = self.extract_images(gltf, out, glb_dir)

        mtl_name = name + ".mtl"
        if self.mtl_var.get():
            self.write_mtl(gltf, os.path.join(out, mtl_name), texture_names, material_names)

        if self.obj_var.get():
            self.write_obj(gltf, glb_dir, os.path.join(out, name + ".obj"), mtl_name, material_names)

    def convert(self):
        if not self.files:
            messagebox.showwarning("No files", "Select one or more GLB files first.")
            return
        if not self.output_dir:
            messagebox.showwarning("No output", "Choose an output folder first.")
            return
        if GLTF2 is None:
            messagebox.showerror("Missing dependency",
                                  "Install dependencies first:\n\npip install pygltflib pillow")
            return

        self.convert_btn.state(["disabled"])
        errors = []
        try:
            for i, src in enumerate(self.files, 1):
                self.status.set(f"Converting {i}/{len(self.files)}: {os.path.basename(src)}")
                self.root.update_idletasks()
                try:
                    self.convert_one(src)
                except Exception as e:
                    errors.append(f"{os.path.basename(src)}: {e}")

            if errors:
                messagebox.showwarning(
                    "Finished with errors",
                    f"Converted {len(self.files) - len(errors)} / {len(self.files)} files.\n\n"
                    + "\n".join(errors[:10])
                )
            else:
                messagebox.showinfo("Done", f"Converted {len(self.files)} GLB file(s).")
            self.status.set("Ready")
        finally:
            self.convert_btn.state(["!disabled"])


if __name__ == "__main__":
    root = tk.Tk()
    app = GLBExtractor(root)
    root.mainloop()
